document.addEventListener("DOMContentLoaded", () => {
  const days = document.querySelectorAll(".day");
  const eventData = JSON.parse(localStorage.getItem("events")) || {};

  // Função para atualizar os eventos no DOM
  function renderEvents() {
    days.forEach(day => {
      const dayNumber = day.dataset.day;
      const eventText = eventData[dayNumber];

      // Remove evento antigo
      const oldEvent = day.querySelector(".event");
      if (oldEvent) oldEvent.remove();

      // Se existir evento salvo
      if (eventText) {
        const span = document.createElement("span");
        span.classList.add("event");
        span.textContent = eventText;
        day.appendChild(span);
      }
    });
  }

  // Clique para adicionar ou editar evento
  days.forEach(day => {
    day.addEventListener("click", () => {
      const dayNumber = day.dataset.day;
      const existingEvent = eventData[dayNumber] || "";

      const newEvent = prompt(
        existingEvent
          ? `Editar ou apagar evento do dia ${dayNumber}:`
          : `Adicionar evento no dia ${dayNumber}:`,
        existingEvent
      );

      if (newEvent === null) return; // cancelado

      if (newEvent.trim() === "") {
        delete eventData[dayNumber];
      } else {
        eventData[dayNumber] = newEvent.trim();
      }

      localStorage.setItem("events", JSON.stringify(eventData));
      renderEvents();
    });
  });

  renderEvents();
});